/*
 Navicat Premium Data Transfer

 Source Server         : remote-106.12.163.127
 Source Server Type    : MySQL
 Source Server Version : 50728
 Source Host           : 106.12.163.127:3306
 Source Schema         : ymall

 Target Server Type    : MySQL
 Target Server Version : 50728
 File Encoding         : 65001

 Date: 17/11/2020 09:53:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ymall_store_goods
-- ----------------------------
DROP TABLE IF EXISTS `ymall_store_goods`;
CREATE TABLE `ymall_store_goods`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) DEFAULT NULL COMMENT '卖家用户id',
  `store_id` int(11) DEFAULT NULL COMMENT '卖家店铺id',
  `goods_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `goods_icon_1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `goods_icon_2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `goods_icon_3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `goods_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `goods_price_percentage` int(11) DEFAULT NULL COMMENT '商品打折力度：比如打5折，则存储5',
  `goods_price` decimal(10, 2) DEFAULT NULL COMMENT '商品原价格',
  `goods_sale_price` decimal(10, 2) DEFAULT NULL COMMENT '商品优惠价格：存储优惠价',
  `goods_nums` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '商品库存',
  `create_time` datetime(0) DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
